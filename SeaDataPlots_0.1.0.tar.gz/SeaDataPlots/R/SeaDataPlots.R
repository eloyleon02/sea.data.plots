calculate_and_plot_temperature_difference <- function(df, years = NULL, depths = NULL, monthNumberColumn = "MonthNumber") {
  # Filter data based on provided years and depths
  if(is.null(years) | is.null(depths)){
    cat("You need to specify years and depths")
  }

  df <- df[df[, monthNumberColumn] != 13,]

  depths.lag <- c()
  for(dep in depths){
    dep.string.lag <- paste("lag", dep, sep="")
    df[, dep.string.lag] <- df[, dep] - lag(df[, dep])
    depths.lag <- c(depths.lag, dep.string.lag)
  }

  # Filter by Years. We do this after calculations, since for calculating the lag for January 2005,
  # we need December 2004, and if we did the filtering previously, there could be cases where
  # we wouldn't have this value

  df <- df[df$Year %in% c(years), ]

  # for average of all years
  yearly.average <- data.frame(
    df[,c(monthNumberColumn, depths.lag)] %>%
      group_by_at(1) %>%
      summarise_at(depths.lag, mean, na.rm = TRUE)
  )

  # Create color palette with different color for each year
  cc <- scales::seq_gradient_pal("blue", "green", "Lab")(seq(0, 1, length.out=length(years)))
  # Preprocess for plotting
  yearly.average <- yearly.average[order(as.numeric(yearly.average[, monthNumberColumn])),,drop=F]
  df <- df[order(as.numeric(df[, monthNumberColumn])),,drop=F]

  # Create a graph for each year
  par(xpd=TRUE)
  for(dep.lag in depths.lag){
    yupper <- max(df[, dep.lag], na.rm = T) + 0.1
    ylower <- min(df[, dep.lag], na.rm = T) - 0.1
    cnt = 1 # counter
    for(year in years){
      df_year <- dplyr::filter(df, Year == year)
      if (cnt == 1){
        plot(df_year[, monthNumberColumn], df_year[, dep.lag], col=cc[cnt],
             pch = 16, ylim = c(ylower, yupper),
             main = paste(dep.lag, " by month: ", sep=""), xlab = "Year", ylab = "Temperature lag",
             xaxt="n")
        axis(1, at = seq(12), labels = names.short[1:12], cex.axis = 0.8)
      }else{
        points(df_year[, monthNumberColumn], df_year[, dep.lag], col=cc[cnt], pch = 16)
      }
      lines(df_year[, monthNumberColumn], df_year[, dep.lag], col=cc[cnt])
      cnt = cnt + 1
    }
    points(yearly.average[, monthNumberColumn], yearly.average[, dep.lag],
           col="red", pch = 16)
    lines(yearly.average[, monthNumberColumn], yearly.average[, dep.lag], col="red", lwd=2)
    legend("topleft", legend=c("Yearly average", years),
           col = c("red", cc),
           pch=16, cex=0.6, box.lty=0, bg="transparent")
  }
}


calculate_and_plot_temperature_difference <- function(df, years = NULL, depths = NULL, monthNumberColumn = "MonthNumber") {
  if(is.null(years) | is.null(depths)){
    cat("You need to specify years and depths")
  }

  # Filter by years
  df <- df[df$Year %in% c(years), ]
  # Sort firstly by indicator of past years
  df <- df[order(as.numeric(df$IsPastYears, df$Year, df[, monthNumberColumn])),,drop=F]
  # Now first half are historical data,
  # sorting by other columns as secondary and third key makes the two dataframes match
  df.nhist <- df[1:(nrow(df)/2), ]
  df.hist <- df[(nrow(df)/2 + 1): nrow(df), ]
  df.fin <- df.nhist
  for(dep in depths){
    df.fin[, dep] <- df.nhist[, dep] - df.hist[, dep]
  }

  yearly.average <- data.frame(
    df.fin[,c(monthNumberColumn, depths)] %>%
      group_by_at(1) %>%
      summarise_at(depths, mean, na.rm = TRUE)
  )

  # Create color palette with different color for each year
  cc <- scales::seq_gradient_pal("blue", "green", "Lab")(seq(0, 1, length.out=length(years)))
  # Preprocess for plotting
  yearly.average <- yearly.average[order(as.numeric(yearly.average[, monthNumberColumn])),,drop=F]
  df.fin <- df.fin[order(as.numeric(df.fin[, monthNumberColumn])),,drop=F]

  # Create a graph for each year
  par(xpd=TRUE)
  for(dep.lag in depths){
    yupper <- max(df.fin[, dep.lag], na.rm = T) + 0.1
    ylower <- min(df.fin[, dep.lag], na.rm = T) - 0.1
    cnt = 1 # counter
    for(year in years){
      df_year <- dplyr::filter(df.fin, Year == year)
      if (cnt == 1){
        plot(df_year[, monthNumberColumn], df_year[, dep.lag], col=cc[cnt],
             pch = 16, ylim = c(ylower, yupper),
             main = paste("Temperature change from historical data by month:", dep.lag, sep=""),
             xlab = "Year", ylab = "Temperature change from past years",
             xaxt="n")
        axis(1, at = seq(13), labels = names.short, cex.axis = 0.8)
      }else{
        points(df_year[, monthNumberColumn], df_year[, dep.lag], col=cc[cnt], pch = 16)
      }
      lines(df_year[, monthNumberColumn], df_year[, dep.lag], col=cc[cnt])
      cnt = cnt + 1
    }
    points(yearly.average[, monthNumberColumn], yearly.average[, dep.lag],
           col="red", pch = 16)
    lines(yearly.average[, monthNumberColumn], yearly.average[, dep.lag], col="red", lwd=2)
    legend("bottomleft", legend=c("Yearly average", years),
           col = c("red", cc),
           pch=16, cex=0.6, box.lty=0, bg="transparent")
  }
}
